const { eslint } = require('@packages/devtools');

module.exports = eslint;