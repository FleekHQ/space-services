const { jest } = require('@packages/devtools');

module.exports = jest;