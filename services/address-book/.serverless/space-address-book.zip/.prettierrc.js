const { prettier } = require('@packages/devtools');

module.exports = prettier;