export { createIdentity } from './create-identity';
export {
  getIdentityByAddress,
  getIdentityByUsername,
  getIdentities,
} from './get-identity';
