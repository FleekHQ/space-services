
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'danielterminal',
  applicationName: 'space-app',
  appUid: 'hfFtJg34YWf8BRqjtG',
  orgUid: '5rBZltHQxV2xGYtNMt',
  deploymentUid: '0f2ae73e-d975-4970-8884-1734106e2e44',
  serviceName: 'space-address-book',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '3.6.13',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'space-address-book-dev-getIdentityByUsername', timeout: 6 };

try {
  const userHandler = require('./dist/index.js');
  module.exports.handler = serverlessSDK.handler(userHandler.getIdentityByUsername, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}